# GroupProject

[Link to my webpage on the Web](https://abollma.github.io/GroupProject/)
